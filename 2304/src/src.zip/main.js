// main.js - メインプロセス

const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

let mainWindow;
let tasks = [];

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 400,
    height: 800,
    webPreferences: {
      nodeIntegration: true,
    },
  });

  mainWindow.loadFile('index.html');

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.on('ready', createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

ipcMain.on('add-task', (event, task) => {
  tasks.push(task);
  event.reply('update-tasks', tasks);
});

ipcMain.on('delete-task', (event, index) => {
  tasks.splice(index, 1);
  event.reply('update-tasks', tasks);
});
